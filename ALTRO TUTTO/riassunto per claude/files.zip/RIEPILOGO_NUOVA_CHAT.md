# RIEPILOGO PROGETTO — Dashboard FIP Sardegna
## Da incollare all'inizio della nuova chat insieme all'ultimo template.html

---

## Contesto
Dashboard web per il Comitato Regionale FIP Sardegna, stagione 2025/2026.
- File principale: `template.html` (~712KB, file singolo HTML+CSS+JS)
- Deploy automatico via GitHub Actions → GitHub Pages
- URL live: https://nonamefip.github.io/fpsrdg/

## Infrastruttura
- `scripts/template.html` — tutto in un file (HTML + CSS + JS inline)
- `scripts/fip_scraper.py` — scarica dati dal sito fip.it giorno per giorno
- `scripts/gen_data.py` — genera il JSON
- `scripts/build.py` — inietta `__DATA__` nel template e produce il file finale
- `.github/workflows/main.yml` — cron `30 2 * * *`, lancia i 3 script in sequenza
- `token.txt` — token GitHub (stessa cartella)
- URL live: https://nonamefip.github.io/fpsrdg/

## Struttura dati chiave
```javascript
D.gare[]          // gare disputate (con Risultato)
D.gare_future[]   // gare future/senza risultato
D.persons{}       // arbitri/udc/osservatori
D.squads{} / SQ{} // squadre
D.campi{}         // campi
D.provvedimenti[] // provvedimenti disciplinari (solitamente vuoto — estratto dal campo g['Provvedimenti'])
CAMPO_GPS{}       // coordinate + city per ogni campo
PC{}              // colori province: CA=#d63031, SS=#0984e3, NU=#e17055, OR=#00b894, SU=#6c5ce7
CAMPS[]           // lista campionati
CAMP_META{}       // metadati campionati
```

## Campi gara
`Numero Gara, Data, Ora, Campionato, Girone, Fase, Squadra Casa, Squadra Ospite, Punti Casa, Punti Ospite, Risultato, Arbitro 1, Arbitro 2, Segnapunti, Cronometrista, 24 Secondi, Addetto Referto, Osservatore, Campo, Stato Gara, Provvedimenti`

## Pagine del template
`home, classifica, prossime, tutti, arbitri, udc, osservatori, squadre, h2h, gruppi, campionati, province, gare, copertura, mappa, provvedimenti, h2h-arb, campi, resoconto, aggiornamento`

---

## SESSIONE DI OGGI — Modifiche apportate

### 1. fip_scraper.py — Fix estrazione Provvedimenti
**Problema:** il campo `Provvedimenti` era sempre vuoto perché `get_info()` cercava `div.value` ma FIP usa `p.value.value--provvedimento`.
**Fix:** cambiata riga 53 da `info.find("div", class_="value")` a `info.find(class_="value")`.
**Fatto:** full-refresh eseguito, ora 284 provvedimenti presenti.

### 2. Pagina Provvedimenti — Miglioramenti UI
Aggiunti rispetto alla versione precedente:
- **Filtro Tipo** (squalifica/ammonizione/inibitoria/diffida/sospensione/deplorazione)
- **Filtro Provincia** (CA/SS/NU/OR/SU)
- **Filtro Arbitro coinvolto** (con autocomplete — funzione `fpvArbSuggest()`)
- **4 KPI cliccabili** in cima: Totali / Attivi / Scaduti / Persone coinvolte
- **Riquadro "Per tipo"** con barre colorate, cliccabile filtra la tabella
- **Classifiche complete** Squadre e Arbitri coinvolti (non più solo top 8), numeri cliccabili
- **Tabella "Persone sanzionate"** con società, N° provvedimenti, tipi, durata totale giorni, stato
- **Colonna Stato (ATTIVO/SCADUTO)** nella tabella principale

### 3. Colonna ⚠️ Provv. nella classifica arbitri
Aggiunta colonna in `renderPersonsTable` che mostra il numero di gare con provvedimenti per ogni arbitro. Cliccando si va alla pagina Provvedimenti filtrata per quell'arbitro.

### 4. Tab ⚠️ Provv. nella scheda arbitro
Appare solo se l'arbitro ha gare con provvedimenti. Lista tutte le gare con i dettagli, cliccando sulla riga si apre la scheda gara.

### 5. Tab ⚠️ Provv. nella scheda squadra
Appare solo se la squadra ha provvedimenti a suo carico. Lista provvedimenti con badge ATTIVO/SCADUTO.

### 6. Fix parseProvv — Parser provvedimenti FIP
**Problema critico:** FIP usa nomi società diversi dal database (es. `A.D. PALLACANESTRO OLIMPIA` vs `PALL. OLIMPIA OLBIA`).
**Soluzione:** `parseProvv(testo, casaGara, ospiteGara)` ora riceve casa e ospite della gara e fa match per parole chiave (>3 chars) tra il nome FIP e le squadre reali.

**Formati FIP gestiti:**
- `soc. SOCIETA:NOME COGNOME tipo per motivo [art. X RG]` → squalifica/inibitoria con persona
- `soc. SOCIETA:Ammonizione per motivo [art. X RG]` → ammonizione alla società senza persona
- `soc. SOCIETA:NOME deplorazione per motivo` → deplorazione (nuovo tipo, verde #16a085)
- Testi liberi senza ":" → tipo generico "provvedimento"

**Fix duplicati:** dedup a monte in `initProvvedimenti` per chiave `num_gara+testo`, prima di qualsiasi parsing.

---

## Stato attuale dei bug

### Risolti oggi
- ✅ Provvedimenti estratti dallo scraper
- ✅ Duplicati eliminati alla radice
- ✅ Match società FIP → squadra reale
- ✅ Ammonizioni senza persona gestite
- ✅ Deplorazione aggiunta come tipo
- ✅ Numeri cliccabili nelle classifiche
- ✅ Filtri provincia e arbitro
- ✅ Tab provvedimenti in scheda arbitro e squadra

### Aperti / da verificare nella prossima sessione
- ⚠️ **Azara non trovato** — `PROVV.filter(p=>p.testo.toLowerCase().includes('azara'))` restituisce array vuoto. Non è nei dati FIP, verificare se il nome è scritto diversamente
- ⚠️ **Tab provvedimenti scheda squadra** — da verificare che riappaia dopo i fix di oggi
- ⚠️ **Gare con arbitro singolo** — il campo Arbitro 1 a volte è vuoto, Arbitro 2 è presente: verificare
- ⚠️ **Tab Cammino e Trend** nella scheda arbitro sono vuoti (contenuto spostato in Statistiche) — da rimuovere
- ⚠️ **Pagine vuote** `aggiornamento`, `h2h-arb` — da rimuovere o implementare
- ⚠️ **~20 funzioni JS probabilmente inutilizzate** — da pulire
- ⚠️ **0 media queries mobile** — responsività non implementata

---

## TODO rimandati (dalla sessione precedente)
- Mappa spostamenti arbitro su Sardegna
- Confronto con media categoria
- Alert ripetizioni (>3 volte stessa squadra consecutiva)
- Dark mode
- Breadcrumb nei modali
- Viste preimpostate classifica arbitri

---

## Note tecniche importanti
- **PROVV** è una variabile globale `let PROVV=D.provvedimenti||[]` inizializzata in `initProvvedimenti()`
- **parseProvv(testo, casa, ospite)** — passa sempre tutti e 3 i parametri
- **pns(nome)** — normalizza nome persona (rimuove provincia, spazi)
- **campColor(camp)** — colore campionato
- **openGara(numGara)** — apre scheda gara a tutto schermo
- **openPersona(nome)** / **openSquadra(nome)** — aprono le schede modali
- **swTabId(btn, id)** — switcha tab per ID (usato nella scheda persona)
- **swTab(btn, prefix)** — switcha tab per prefisso progressivo (usato nella scheda squadra)
- Il template viene testato SOLO su https://nonamefip.github.io/fpsrdg/ — in locale mostra 0 dati perché manca `__DATA__`

---

Incolla questo testo + l'ultimo template.html nella nuova chat e siamo pronti.
