# 📋 GUIDA INSTALLAZIONE — Redattore Documenti Offline
## Windows 10/11 · i7 · 16GB RAM

---

## COSA INSTALLERAI
- **Ollama** → il programma che fa girare l'AI sul tuo PC
- **Mistral 7B** → il modello AI (funziona bene in italiano, ~4GB)
- **RedattoreDocumenti.html** → l'app che hai già scaricato

---

## PASSO 1 — Scarica e installa Ollama

1. Vai su: https://ollama.com/download
2. Clicca su **"Download for Windows"**
3. Apri il file `.exe` scaricato e segui l'installazione (avanti, avanti, installa)
4. Al termine, Ollama si avvia automaticamente in background
   - Vedrai una piccola icona nella barra delle applicazioni in basso a destra

---

## PASSO 2 — Scarica il modello AI (Mistral)

1. Premi i tasti **Windows + R** sulla tastiera
2. Scrivi `cmd` e premi Invio → si apre il Prompt dei comandi
3. Copia e incolla questo comando, poi premi Invio:

```
ollama pull mistral
```

4. Aspetta il download (~4 GB). Vedrai una barra di avanzamento.
   - Con connessione normale ci vogliono 5-15 minuti
5. Quando finisce vedrai scritto `success`

---

## PASSO 3 — Avvia Ollama (ogni volta che vuoi usare l'app)

Ollama di solito parte automaticamente con Windows. Per verificarlo:

1. Guarda la barra in basso a destra del desktop
2. Se vedi l'icona di Ollama (una piccola lama/fiamma) → è già attivo ✅
3. Se non la vedi → cerca "Ollama" nel menu Start e aprilo

In alternativa, puoi avviarlo dal Prompt dei comandi:
```
ollama serve
```

---

## PASSO 4 — Usa l'app

1. Apri il file **RedattoreDocumenti.html** con il tuo browser (doppio clic)
2. In alto a destra vedrai lo stato della connessione con Ollama
3. Se vedi il pallino **verde** → tutto funziona! ✅
4. Se il pallino è **rosso** → Ollama non è avviato, torna al Passo 3

---

## COME SI USA L'APP

1. **Scegli il tipo di documento** nella colonna di sinistra:
   - Lettera a Ente Pubblico (Comune, ASL, INPS...)
   - Ricorso
   - Diffida
   - Richiesta a privato/azienda
   - Accesso agli atti
   - Esposto/Segnalazione
   - Testo Libero

2. **Compila i tuoi dati** (nome, indirizzo, contatti) — opzionali ma utili

3. **Scegli il tono** (formale, deciso, conciliante, urgente)

4. **Scrivi la situazione** nel riquadro grande in linguaggio normale:
   - Non devi usare termini legali
   - Scrivi come spiegheresti la cosa a un amico
   - Includi date, nomi, fatti importanti

5. Premi **"Genera Documento"** e aspetta qualche secondo

6. Il documento apparirà nel riquadro in basso
   - Puoi **copiarlo** negli appunti
   - Puoi **salvarlo** come file .txt

---

## RISOLUZIONE PROBLEMI

**Pallino rosso / Ollama non risponde:**
- Apri il menu Start → cerca "Ollama" → aprilo
- Oppure apri il Prompt dei comandi e scrivi: `ollama serve`

**Il documento è in inglese:**
- Specifica nella descrizione: "Rispondi in italiano"
- Oppure cambia modello: nel campo "Modello Ollama" scrivi `llama3` 
  (prima esegui: `ollama pull llama3`)

**La generazione è lenta:**
- Normale per il tuo PC (CPU senza GPU dedicata)
- Aspetta 20-60 secondi, dipende dalla lunghezza del documento
- Non chiudere il browser mentre genera

**Errore "model not found":**
- Apri Prompt dei comandi e riesegui: `ollama pull mistral`

---

## MODELLI ALTERNATIVI

Se vuoi provare altri modelli (da installare con `ollama pull NOME`):

| Modello | Comando | Dimensione | Note |
|---------|---------|------------|------|
| Mistral (consigliato) | `ollama pull mistral` | ~4 GB | Ottimo in italiano |
| Llama 3.2 | `ollama pull llama3.2` | ~2 GB | Più veloce, meno preciso |
| Llama 3.1 8B | `ollama pull llama3.1` | ~4.7 GB | Buona qualità |

---

## PRIVACY

✅ Tutto funziona **esclusivamente sul tuo PC**
✅ Nessun dato viene inviato a server esterni
✅ Nessuna connessione internet necessaria dopo l'installazione
✅ I tuoi documenti rimangono privati

---

*Guida preparata per: Windows 11 · Intel i7-1065G7 · 16GB RAM*
